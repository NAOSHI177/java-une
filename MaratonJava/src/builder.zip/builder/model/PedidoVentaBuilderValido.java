package builder.model;



public class PedidoVentaBuilderValido {

	private PedidoVenta instancia;
	
	public PedidoVentaBuilderValido(PedidoVenta instancia) {
	    this.instancia = instancia;
    }

	public PedidoVenta construir() {
		return this.instancia;
	}
	
}